export class User {
    
   firstname:string | any;
   lastname:string | any;
   username:string | any;
   email:string | any;
   password:string | any;
}
