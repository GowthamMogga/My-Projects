export class Foods{
    id!:number;
    price!:number;
    name!:string;
    notfavourite:boolean=false;
    star:number=0;
    tags!:string[];
    image!:string;
    origins!:string[];
    Time!:string;

}