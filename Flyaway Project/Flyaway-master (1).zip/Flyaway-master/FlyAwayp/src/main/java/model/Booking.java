package model;

public class Booking {
	
    // flight details
    public static String flight_booking_id;
    public static String ticket_price;//-->database
    public static String flight_name;
    
  
    
    // Booking  details
    public static String passenger_name; //---> pname -->saikrishna
    public static String passenger_email; //---> email -->skrishna694
    public static String passenger_phone; //----> phone --9989300172

    // payment details
    public static String name_on_card;
    public static String card_details;
    
    }





